import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-ticket-list',
  templateUrl: './ticket-list.component.html',
  styleUrls: ['./ticket-list.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class TicketListComponent {

}

import { Component,ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class LoginComponent {
  
  username: string = '';
  password: string = '';

  constructor(private router: Router) {}

  login(): void {
    // Call your login API here with this.username and this.password
    // For demonstration purposes, let's assume a successful login
    const token = 'your_generated_token';
    localStorage.setItem('token', token);
    this.router.navigate(['/dashboard']);
  }
}
